package carshop.Interface;

public interface Admin {
    double getIncome(); // Суммарная цена проданных автомобилей
}
