package carshop;

import carshop.impl.*;

public class Main {
    public static void main(String[] args) {
        MyOwnAutoShop shop = new MyOwnAutoShop();

        System.out.println("Цвета автомобилей в магазине: " + shop.getCarColors());
        System.out.println("Общая стоимость автомобилей в магазине: " + shop.getCarsPrice());

        System.out.println("Цена автомобиля с ID 0: " + shop.getCarPrice(0));
        System.out.println("Цвет автомобиля с ID 0: " + shop.getCarColor(0));

        shop.purchaseCar(0);
        System.out.println("Автомобиль с ID 0 куплен");
        System.out.println("Доход от продажи автомобилей: " + shop.getIncome());
    }
}